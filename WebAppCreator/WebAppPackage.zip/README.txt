Dear reader,

HybridApp (Legacy) v1.0.1

If you're reading this, this is the last version of the "old" HybridApp.
I used Visual Basic.NET and Visual Studio 2019 originally. And the .NET Framework 4.7.2.
HybridApp started on the 26th June 2023. I thought of the idea much earlier, but then,
during an Apple launch event at some point, they announced that MY idea would be added
to Safari on Mac. I never heard of it again. Hope they did well with that.

All of these are finished, so, take care. Enjoy the last version of HybridApp.

 - Nathan Gill
 - nathan.j.gill@outlook.com
 - https://github.com/OldUser101

Public Sub Thanks()
	MsgBox("Have a nice day :)")
End Sub

P.S.
The webInfo.txt file format is s**t. It's the name of the app (displayed in titlebar) on the first line,
then the URL, it MUST start with the protocol to be used (e.g. http://). "NULL" is used as a placeholder, 
and may cause errors if actually used.

Try to find the hidden click area on the HybridApp Creator main window!

